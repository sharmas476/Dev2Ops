DROP TABLE EMAILNOTIFICATION;

CREATE TABLE  EMAILNOTIFICATION (
  Task_ID INT NOT NULL,
  Task_Name varchar(20) NOT NULL,
  Sender_EmailId  varchar(100) NOT NULL,
  Receiver_EmailId varchar(100) NOT NULL, 
  Subject varchar(50) NOT NULL,
  Message varchar(250) NOT NULL,
  PRIMARY KEY (Task_ID)
) ;