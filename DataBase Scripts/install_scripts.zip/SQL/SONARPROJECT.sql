drop table SONARPROJECT;

CREATE TABLE  SONARPROJECT (
  ID INT NOT NULL ,
  PROJECT varchar(50),
  SONAR_NAME varchar(50),
  ISACTIVE char(1),
  PRIMARY KEY (ID) 
 ) ;