drop table D2OCONFIG;

CREATE TABLE  D2OCONFIG (
  ID INT NOT NULL ,
  Key varchar(50),
  SECONDARY_PROJECT_NAME varchar(50),
  RELEASE varchar(50),
  Value varchar(500),
  PRIMARY KEY (ID) 
 ) ;
 
insert into D2OCONFIG (ID, SECONDARY_PROJECT_NAME, RELEASE, Key, Value) values (1, null, null, 'SCM_URL', 'http://localhost:8181/SCM_Project');
insert into D2OCONFIG (ID, SECONDARY_PROJECT_NAME, RELEASE, Key, Value) values (2, null, null, 'MAIL_SCRIPT', '/home/mailsender.ksh');
insert into D2OCONFIG (ID, SECONDARY_PROJECT_NAME, RELEASE, Key, Value) values (3, null, null, 'SCHEDULER_USER', '3');
insert into D2OCONFIG (ID, SECONDARY_PROJECT_NAME, RELEASE, Key, Value) values (4, null, null, 'CurrentTool', 'Jenkins');
COMMIT;