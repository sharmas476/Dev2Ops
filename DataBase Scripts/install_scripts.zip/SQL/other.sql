
select constraint_name
from user_cons_columns
where table_name = 'PRIMARYPROJECTMASTER'
and column_name = 'MODIFIED_BY';
SYS_C0043636
--
--
--
alter table PRIMARYPROJECTMASTER drop constraint SYS_C0043636;



    alter table rolemaster drop column modified_by cascade constraints;