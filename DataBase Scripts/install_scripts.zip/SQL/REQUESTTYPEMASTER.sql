
DROP TABLE REQUESTTYPEMASTER;

CREATE TABLE  REQUESTTYPEMASTER (
   ID INT NOT NULL,
  REQUESTTYPE varchar(90) DEFAULT NULL,
  Status INT not null, 
  CREATED_BY INT,
  CREATE_DATE date,
  MODIFIED_BY INT,
  MODIFIED_DATE date ,
    PRIMARY KEY (ID)
) ;



INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (1, 'Branch Creation', 1 ,  1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (2, 'Deployment' , 1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (3, 'CR creation',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (4, 'Branch Access',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (5, 'Environment Upgrade',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE  , status ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (6, 'Code Merge',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (7, 'SVN Access',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (8, 'HF',  1 ,1 , now(), 1,  now());

INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (9, 'Property updates',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (10, 'EAR Bounce',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE  , status ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (11, 'Server Bounce', 1 , 1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (12, 'Jenkin Setup',  1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (14, 'Jira', 1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status  ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (15, 'Other', 1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (16, 'MEnv-Deployment' , 1 ,1 , now(), 1,  now());
INSERT INTO REQUESTTYPEMASTER (ID, REQUESTTYPE , status ,CREATED_BY , CREATE_DATE ,MODIFIED_BY , MODIFIED_DATE ) values (17, 'Rollback' , 1 ,1 , now(), 1,  now());


update REQUESTTYPEMASTER set REQUESTTYPE = 'Deployment Rollback' where id = 17 ;



update REQUESTTYPEMASTER set status = 0 where id in (1, 3, 6, 11, 4 , 5 , 7 , 8 , 9 , 12 , 13 , 14 , 15 , 16, 17, 10 );
update requesttypemaster set status =1 where id=11;
update requesttypemaster set RequestType ='Database Upgrade' where id=11;
update requesttypemaster set RequestType='Deploy Primary Backend', status=1 where id=1;
update requesttypemaster set RequestType='Deploy Secondary Backend', status=1 where id=3;

commit;
