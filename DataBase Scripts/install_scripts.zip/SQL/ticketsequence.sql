
DROP TABLE ticketsequence;

CREATE TABLE  ticketsequence (
  seq_no INT NOT NULL,
  table_name varchar(100) NOT NULL,
  created_by INT ,
  created_date date,
  modified_by INT,
  modified_date date 
) ;

--

INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES( 2 , 'usermaster' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES( 2 , 'rolemaster' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1, 'ticketdetails' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1, 'tickethistory' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1, 'buildstatus' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1, 'WS' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1 , 'QUALITYGATEMASTER' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1 , 'SQTMASTER' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1 , 'ASMASTER' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1 , 'FTMASTER' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(1 , 'CTMCONFIG' , 1, now(),  1,  now()) ;

INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(5 , 'PRIMARYPROJECTMASTER' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(26 , 'SECONDARYPROJECTMASTER' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(25 , 'ENVIRONMENTMASTER' , 1, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(27 , 'D2OSCRIPTS' , 2, now(),  1,  now()) ;
INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(3 , 'CONFIGURATIONMASTER' , 2, now(),  1,  now()) ;

INSERT INTO ticketsequence (seq_no ,table_name, created_by , created_date , modified_by ,modified_date ) VALUES(5 , 'RELEASEMASTER' , 2, now(),  1,  now()) ;
INSERT INTO TICKETSEQUENCE (SEQ_NO, TABLE_NAME, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE) VALUES ('1', 'EVENTMAILRECIPIENT', '1',now(), 1, now());

