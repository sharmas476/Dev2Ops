DROP TABLE SCMPAGEMASTER;
CREATE TABLE  SCMPAGEMASTER (
  ID INT NOT NULL ,
  PAGENAME varchar(50) NOT NULL,
  STATUS INT not null,
  CREATED_BY INT NOT NULL ,
  CREATED_DATE date NOT NULL,
  MODIFIED_BY  INT ,
  MODIFIED_DATE date ,
  PRIMARY KEY (ID) 
 ) ;

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(1,'HOME', 1, 1, now(), 1, now());

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(2,'DASHBOARD' , 1, 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(3,'ENVDASHBOARD', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(4,'D2ODASHBOARD', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(5,'JENKINSDASHBOARD', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(6,'SONARDASHBOARD', 1 , 1, now(), 1, now());

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(7,'ONDEMAND', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(8,'CREATETASK', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(9,'TASKAPPROVAL', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(10,'TASKSTATUS', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(11,'TASKHISTORY', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(12,'SCMQUEUE', 1 , 1, now(), 1, now());

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(13,'CONTINUOUSDEPLOYMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(14,'SCHEDULERTASKS', 1 , 1, now(), 1, now());

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(15,'ADMIN', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(16,'SCHEDULERMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(17,'BUILDPROVISIONING', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(18,'ROLEMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(19,'USERMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(20,'QUALITYGATES', 1 , 1, now(), 1, now());

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(21,'WELCOME',1,1,  now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(22,'PROFILE',1, 1 , now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(23,'ABOUTUS',1, 1,  now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(24,'LOGOUT',1, 1 , now(), 1, now());

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(25,'D2OREPORTS', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(26,'DEPLOYMENTREPORTS', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(27,'OPSTASKSTATUS', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(28,'QUALITYGATEREPORTS', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(29,'D2OCONFIG', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(30,'PROJECTMANAGEMENT', 1 , 1, now(), 1, now());

INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(31,'APPLICATIONMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(32,'RELEASEMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(33,'ENVIRONMENTMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(34,'INFRAMSANITYMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(35,'ADMINCONFIGURATIONMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(36,'TESTINGMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(37,'CCBAPPROVALS', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(38,'EMAILMANAGEMENT', 1 , 1, now(), 1, now());
INSERT INTO SCMPAGEMASTER (ID, PAGENAME, STATUS , created_by, created_date, modified_by, modified_date) VALUES(39,'PRODTASKAPPROVAL', 1 , 1, now(), 1, now());

