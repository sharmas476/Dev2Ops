CREATE TABLE  CookieValues (
  ID INT NOT NULL ,
  Key varchar(50),
  Value varchar(3000),
  PRIMARY KEY (ID) 
 ) ;
 
 
 
 insert into CookieValues (ID,  Key, Value) values (1, 'COOKIESTRING', '');