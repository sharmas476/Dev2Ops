DROP TABLE USERMASTER;
CREATE TABLE  usermaster (
  ID INT NOT NULL ,
  username varchar(20) NOT NULL,
  useremailid varchar(40) DEFAULT NULL,
  password varchar(100) DEFAULT NULL,
  status INT not null,
  created_by INT NOT NULL ,
  created_date date NOT NULL,
  modified_by  INT ,
  modified_date date ,
  PRIMARY KEY (ID) 
 ) ;

INSERT INTO usermaster (id, username, useremailid, password,  STATUS, created_by, created_date, modified_by, modified_date) VALUES(1,'d2o', 'test@techm.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1,  1, now(), 1, now());
INSERT INTO usermaster (id, username, useremailid, password,  STATUS, created_by, created_date, modified_by, modified_date) VALUES(2,'developer', 'sj00332992@techmahindra.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1,  1, now(), 1, now());
INSERT INTO usermaster (id, username, useremailid, password,  STATUS, created_by, created_date, modified_by, modified_date) VALUES(3,'Scheduler', 'd20scheduler@techmahindra.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1,  1, now(), 1, now());