DROP TABLE ROLESCMPAGEMAPPING;
CREATE TABLE  ROLESCMPAGEMAPPING (
  ROLE_ID  INT NOT NULL ,
  SCM_PAGE_ID INT NOT NULL ,
  CREATED_BY INT NOT NULL ,
  CREATED_DATE date NOT NULL,
  MODIFIED_BY  INT ,
  MODIFIED_DATE date ,
 FOREIGN KEY (ROLE_ID) REFERENCES ROLEMASTER(ID),
 FOREIGN KEY (SCM_PAGE_ID) REFERENCES SCMPAGEMASTER(ID)
  ) ;
 


INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE) VALUES(1, 1 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 2 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 3 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 4 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 5 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 6 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 7 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 8 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 9 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 10 , 1, now(), 1, now());

INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 11 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 12 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 13 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 14 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 15 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 16 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 17 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 18 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 19 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 20 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 21 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 22 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 23 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 24 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 25 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 26 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 27 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 28 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 29 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 30 , 1, now(), 1, now());

INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 31 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 32 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 33 , 1, now(), 1, now());

INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 34 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 35 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 36 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 37 , 1, now(), 1, now());
INSERT INTO ROLESCMPAGEMAPPING (ROLE_ID, SCM_PAGE_ID,  created_by, created_date, modified_by, modified_date) VALUES(1, 38 , 1, now(), 1, now());

